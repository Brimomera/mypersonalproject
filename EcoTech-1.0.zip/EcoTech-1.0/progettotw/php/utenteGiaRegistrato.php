<?php
require_once("bootstrap.php");

$templateParams["titolo"] = "Eco-Tech | Login";
$templateParams["contenuto"] = "clienteGiaRegistrato.php";


require("template/base-registration.php");
?>
