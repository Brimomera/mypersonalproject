<?php
require_once("bootstrap.php");

$templateParams["titolo"] = "Eco-Tech | Login";
$templateParams["contenuto"] = "login-form.php";

require("template/base-login.php");
?>
