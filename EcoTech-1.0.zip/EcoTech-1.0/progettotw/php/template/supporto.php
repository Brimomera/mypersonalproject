<div class="botui-app-container col" id="ecobot">
    <bot-ui></bot-ui>
</div>
