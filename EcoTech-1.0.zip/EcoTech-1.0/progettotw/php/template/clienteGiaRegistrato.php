<h1 class="h3 mb-3 fw-normal text-center">Utente Già Registrato</h1>

<div class="form-floating ">
    <p>La mail da lei utilizzata è già utilizzata da un altro utente!</p>
    <a class="btn buttLog" href="registration.php">Registrazione</a>
    <a class="btn buttLog" href="login.php">Esegui Login</a>

</div>
