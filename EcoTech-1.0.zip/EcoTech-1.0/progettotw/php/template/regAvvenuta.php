<h1 class="h3 mb-3 fw-normal text-center">Registrazione</h1>

<div class="form-floating">
    <p>Registrazione Avvenuta con successo!!</p>
    <a class="btn buttLog" href="registration.php">Torna indietro</a>
    <a class="btn buttLog" href="login.php">Login</a>
</div>
