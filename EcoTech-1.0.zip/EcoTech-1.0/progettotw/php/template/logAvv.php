<h1 class="h3 mb-3 fw-normal text-center">Login</h1>

<div class="form-floating">
    <p>Login avvenuto con successo!!</p>
    <a class="btn buttLog" href="index.php">Home Page</a>
    <a class="btn buttLog" href="logout.php">Esegui Logout</a>
</div>
