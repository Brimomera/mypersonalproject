<h1 class="h3 mb-3 fw-normal text-center">Logout</h1>

<div class="form-floating">
    <p>Logout avvenuto con successo!!</p>
    <a class="btn buttLog" href="index.php">Torna alla Home Page</a>
</div>
