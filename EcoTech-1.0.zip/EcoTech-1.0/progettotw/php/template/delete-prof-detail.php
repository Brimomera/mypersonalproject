<div class="card bg-transparent rounded-3 mb-0">

    <!-- Contenuto Card -->
    <div class="card-body">
        <h6>Vuoi cancellare il tuo profilo?</h6>
        <p>Cancellando il tuo profilo, verranno cancellati tutti i tuoi dati.<p>
            <a href="elimina-cliente.php" class="btn btn-danger mb-0">Elimina Account</a>
    </div>


</div>
