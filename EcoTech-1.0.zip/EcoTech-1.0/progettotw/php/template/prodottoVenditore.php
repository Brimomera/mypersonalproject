<div class="container px-4 py-5" id="custom-cards">

    <h2 class="pb-2 border-bottom">Gestione Prodotti</h2>

    <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
      <div class="col">
        <input class="w-10 btn btn-primary btn-lg border-0" type="submit" value="Magazzino"/>
        </br></br>
        <input class="w-10 btn btn-primary btn-lg border-0" type="submit" value="Effettua il Pagamento"/>
      </div>
    </div>
</div>
